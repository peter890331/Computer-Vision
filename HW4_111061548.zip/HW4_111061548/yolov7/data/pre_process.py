import os
import glob
import random
import argparse

from collections import defaultdict

CLASS_NAME = [
    'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat', 'traffic light',
    'fire hydrant', 'stop sign', 'parking meter', 'bench', 'bird', 'cat', 'dog', 'horse', 'sheep', 'cow',
    'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella', 'handbag', 'tie', 'suitcase', 'frisbee',
    'skis', 'snowboard', 'sports ball', 'kite', 'baseball bat', 'baseball glove', 'skateboard', 'surfboard',
    'tennis racket', 'bottle', 'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple',
    'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch',
    'potted plant', 'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone',
    'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'book', 'clock', 'vase', 'scissors', 'teddy bear',
    'hair drier', 'toothbrush'
]

# Q2, Q3 TODO : select "better" images from Q2, Q3 folder
def select_images(image_paths, select_images_method, images_num=200):
    """
    :param image_paths: --> ['your_folder/images1.jpg', 'your_folder/images2.jpg', ...]
    :param images_num: choose the number of images
    :return :
        selected_image_paths = ['your_folder/images10.jpg', 'your_folder/images12.jpg', ...]
    """
    # TODO : select images


    if select_images_method == 1:
        # Random Sampling
        random.shuffle(image_paths)
        selected_image_paths = image_paths[:images_num]

    elif select_images_method == 2:
        # Average Random Sampling
        _170 = [i for i in image_paths if '/170' in i]
        _173 = [i for i in image_paths if '/173' in i]
        _398 = [i for i in image_paths if '/398' in i]
        _410 = [i for i in image_paths if '/410' in i]
        _495 = [i for i in image_paths if '/495' in i]
        _511 = [i for i in image_paths if '/511' in i]

        random.shuffle(_170)
        random.shuffle(_173)
        random.shuffle(_398)
        random.shuffle(_410)
        random.shuffle(_495)
        random.shuffle(_511)

        avg_images_num = round(images_num/6)

        selected_image_paths = _170[:avg_images_num] + _173[:avg_images_num] + _398[:avg_images_num] + _410[:avg_images_num] + _495[:avg_images_num] + _511[:200-avg_images_num*5]

    elif select_images_method == 3:
        # Top 200 most classes
        label_counts = defaultdict(set)
        for path_jpg in image_paths:
            path_txt = path_jpg[:-3] + 'txt'
            try:
              with open(path_txt, 'r') as file:
                  lines = file.readlines()
              for line in lines:
                  class_index = int(line.split()[0])
                  label_counts[path_jpg].add(class_index)
            except: pass

        sorted_paths_counts = sorted(label_counts.items(), key=lambda x: len(x[1]), reverse=True)
        sorted_paths = [paths for paths, _ in sorted_paths_counts]

        selected_image_paths = sorted_paths[:images_num]
        random.shuffle(selected_image_paths)

    elif select_images_method == 4:
        # Top 200 most classes & Average Random Sampling
        label_counts = defaultdict(set)
        for path_jpg in image_paths:
            path_txt = path_jpg[:-3] + 'txt'
            try:
              with open(path_txt, 'r') as file:
                  lines = file.readlines()
              for line in lines:
                  class_index = int(line.split()[0])
                  label_counts[path_jpg].add(class_index)
            except: pass

        sorted_paths_counts = sorted(label_counts.items(), key=lambda x: len(x[1]), reverse=True)
        sorted_paths = [paths for paths, _ in sorted_paths_counts]

        _170 = [i for i in sorted_paths if '/170' in i]
        _173 = [i for i in sorted_paths if '/173' in i]
        _398 = [i for i in sorted_paths if '/398' in i]
        _410 = [i for i in sorted_paths if '/410' in i]
        _495 = [i for i in sorted_paths if '/495' in i]
        _511 = [i for i in sorted_paths if '/511' in i]

        avg_images_num = round(images_num/6)

        selected_image_paths = _170[:avg_images_num] + _173[:avg_images_num] + _398[:avg_images_num] + _410[:avg_images_num] + _495[:avg_images_num] + _511[:200-avg_images_num*5]
        random.shuffle(selected_image_paths)

    return selected_image_paths

# TODO : split train and val images
def split_train_val_path(all_image_paths, random_train_and_val, train_val_ratio=0.9):
    """
    :param all_image_paths: all image paths for question in the data folder
    :param train_val_ratio: ratio of image paths used to split training and validation
    :return :
        train_image_paths = ['your_folder/images1.jpg', 'your_folder/images2.jpg', ...]
        val_image_paths = ['your_folder/images3.jpg', 'your_folder/images4.jpg', ...]
    """
    # TODO : split train and val
    if random_train_and_val == 1:
      random.shuffle(all_image_paths)
    elif random_train_and_val == 0:
      pass

    train_image_paths = all_image_paths[: int(len(all_image_paths) * train_val_ratio)]  # just an example
    val_image_paths = all_image_paths[int(len(all_image_paths) * train_val_ratio):]  # just an example

    return train_image_paths, val_image_paths


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_folder', type=str, default='./data/CityCam', help='path of CityCam datasets folder')
    parser.add_argument('--ques', type=str, default='Q1', choices=['Q1', 'Q2', 'Q3', 'Q3_025', 'Q3_05', 'Q2_Q3_025'], help='question in data_folder')
    parser.add_argument('--select_images_method', type=int, default=1, choices=[1, 2, 3, 4])
    parser.add_argument('--random_train_and_val', type=int, default=1, choices=[0 ,1])
    args = parser.parse_args()
    print(args)

    # Delete data in Q3_temp
    def delete_Q3_temp():
      Q3_temp_path = glob.glob(os.path.join(args.data_folder, 'Q3_temp'))[0]
      Q3_temp = [os.path.join(Q3_temp_path, file) for file in os.listdir(Q3_temp_path)]
      try:
        if os.path.isfile(Q3_temp[0]):
          # Delete files
          for i in Q3_temp:
            os.unlink(i)
          print(f' * Initializing: All data has been deleted.')
      except Exception as e:
          print(f' * Initializing: No data can be deleted.')

    # Copy data to Q3_temp
    def copy_Q3_temp(copy_path):
      #print('copy_path:', copy_path)
      import shutil
      Q3_temp_path = glob.glob(os.path.join(args.data_folder, 'Q3_temp'))[0]
      #print('Q3_temp_path:', Q3_temp_path)
      for j in copy_path:
        Q3 = [os.path.join(j, file) for file in os.listdir(j)]
        #print('Q3:', Q3)
        for i in Q3:
          if os.path.isfile(i):
            shutil.copy(i, Q3_temp_path)

    # Get whole and Test image paths
    if args.ques == 'Q1' or args.ques == 'Q2':
      all_image_paths = glob.glob(os.path.join(args.data_folder, args.ques, '*', '*.jpg'))
      test_image_paths = glob.glob(os.path.join(args.data_folder, 'test', '*' + os.sep + '*.jpg'))
    elif args.ques == 'Q3':
      test_image_paths = glob.glob(os.path.join(args.data_folder, args.ques, '*', '*.jpg'))
    elif args.ques == 'Q3_025':
      delete_Q3_temp()
      copy_Q3_temp(glob.glob(os.path.join(args.data_folder, 'Q3', '*')))
      copy_Q3_temp(glob.glob(os.path.join(args.data_folder, '../..', 'runs', 'detect', 'Q3', 'Q3_pseudo_labels_025', 'labels')))
      all_image_paths = glob.glob(os.path.join(args.data_folder, 'Q3_temp', '*.jpg'))
      test_image_paths = glob.glob(os.path.join(args.data_folder, 'test', '*' + os.sep + '*.jpg'))
      print(' * lens: -----------------------------------')
      print('all_image_paths:  ', len(all_image_paths))
      print('test_image_paths: ', len(test_image_paths))
    elif args.ques == 'Q3_05':
      delete_Q3_temp()
      copy_Q3_temp(glob.glob(os.path.join(args.data_folder, 'Q3', '*')))
      copy_Q3_temp(glob.glob(os.path.join(args.data_folder, '../..', 'runs', 'detect', 'Q3', 'Q3_pseudo_labels_05', 'labels')))
      all_image_paths = glob.glob(os.path.join(args.data_folder, 'Q3_temp', '*.jpg'))
      test_image_paths = glob.glob(os.path.join(args.data_folder, 'test', '*' + os.sep + '*.jpg'))
      print(' * lens: -----------------------------------')
      print('all_image_paths:  ', len(all_image_paths))
      print('test_image_paths: ', len(test_image_paths))
    elif args.ques == 'Q2_Q3_025':
      all_image_paths_Q2 = glob.glob(os.path.join(args.data_folder, 'Q2', '*', '*.jpg'))
      delete_Q3_temp()
      copy_Q3_temp(glob.glob(os.path.join(args.data_folder, 'Q3', '*')))
      copy_Q3_temp(glob.glob(os.path.join(args.data_folder, '../..', 'runs', 'detect', 'Q3', 'Q3_pseudo_labels_025', 'labels')))
      all_image_paths_Q3_025 = glob.glob(os.path.join(args.data_folder, 'Q3_temp', '*.jpg'))
      test_image_paths = glob.glob(os.path.join(args.data_folder, 'test', '*' + os.sep + '*.jpg'))


    # for Q2, Q3: select images
    if args.ques == 'Q1':
      selected_image_paths = all_image_paths
    elif args.ques in ['Q2', 'Q3_025', 'Q3_05']:
      selected_image_paths = select_images(all_image_paths, args.select_images_method, images_num=200)
      #print(len(selected_image_paths))
    elif args.ques == 'Q2_Q3_025':
      selected_image_paths_Q2 = select_images(all_image_paths_Q2, args.select_images_method, images_num=200)
      selected_image_paths_Q3_025 = select_images(all_image_paths_Q3_025, args.select_images_method, images_num=200)
      selected_image_paths = selected_image_paths_Q2 + selected_image_paths_Q3_025
      #print(len(selected_image_paths))

    # split Train and Val
    if args.ques in ['Q1', 'Q2', 'Q3_025', 'Q3_05', 'Q2_Q3_025']:
      train_image_paths, val_image_paths = split_train_val_path(selected_image_paths, args.random_train_and_val)

    if args.ques == 'Q1':
        print(' * train_image_paths: ----------------------')
        print('Q1/173 in train_image_paths: ', len([i for i in train_image_paths if 'Q1/173' in i]))
        print('Q1/398 in train_image_paths: ', len([i for i in train_image_paths if 'Q1/398' in i]))
        print(' * val_image_paths: ------------------------')
        print('Q1/173 in val_image_paths:   ', len([i for i in val_image_paths   if 'Q1/173' in i]))
        print('Q1/398 in val_image_paths:   ', len([i for i in val_image_paths   if 'Q1/398' in i]))
    elif args.ques == 'Q2':
        print(' * train_image_paths: ----------------------')
        print('Q2/170 in train_image_paths: ', len([i for i in train_image_paths if 'Q2/170' in i]))
        print('Q2/173 in train_image_paths: ', len([i for i in train_image_paths if 'Q2/173' in i]))
        print('Q2/398 in train_image_paths: ', len([i for i in train_image_paths if 'Q2/398' in i]))
        print('Q2/410 in train_image_paths: ', len([i for i in train_image_paths if 'Q2/410' in i]))
        print('Q2/495 in train_image_paths: ', len([i for i in train_image_paths if 'Q2/495' in i]))
        print('Q2/511 in train_image_paths: ', len([i for i in train_image_paths if 'Q2/511' in i]))
        print(' * val_image_paths: ------------------------')
        print('Q2/170 in val_image_paths:   ', len([i for i in val_image_paths if 'Q2/170' in i]))
        print('Q2/173 in val_image_paths:   ', len([i for i in val_image_paths if 'Q2/173' in i]))
        print('Q2/398 in val_image_paths:   ', len([i for i in val_image_paths if 'Q2/398' in i]))
        print('Q2/410 in val_image_paths:   ', len([i for i in val_image_paths if 'Q2/410' in i]))
        print('Q2/495 in val_image_paths:   ', len([i for i in val_image_paths if 'Q2/495' in i]))
        print('Q2/511 in val_image_paths:   ', len([i for i in val_image_paths if 'Q2/511' in i]))
    else: 
        print(' * train_image_paths: ----------------------')
        print('/170 in train_image_paths: ', len([i for i in train_image_paths if '/170' in i]))
        print('/173 in train_image_paths: ', len([i for i in train_image_paths if '/173' in i]))
        print('/398 in train_image_paths: ', len([i for i in train_image_paths if '/398' in i]))
        print('/410 in train_image_paths: ', len([i for i in train_image_paths if '/410' in i]))
        print('/495 in train_image_paths: ', len([i for i in train_image_paths if '/495' in i]))
        print('/511 in train_image_paths: ', len([i for i in train_image_paths if '/511' in i]))
        print(' * val_image_paths: ------------------------')
        print('/170 in val_image_paths:   ', len([i for i in val_image_paths if '/170' in i]))
        print('/173 in val_image_paths:   ', len([i for i in val_image_paths if '/173' in i]))
        print('/398 in val_image_paths:   ', len([i for i in val_image_paths if '/398' in i]))
        print('/410 in val_image_paths:   ', len([i for i in val_image_paths if '/410' in i]))
        print('/495 in val_image_paths:   ', len([i for i in val_image_paths if '/495' in i]))
        print('/511 in val_image_paths:   ', len([i for i in val_image_paths if '/511' in i]))

    # write train/val/test info
    if args.ques == 'Q1' or args.ques == 'Q2':
        train_path = os.path.join(args.data_folder, 'train.txt')
        val_path = os.path.join(args.data_folder, 'val.txt')
        test_path = os.path.join(args.data_folder, 'test.txt')
        with open(train_path, 'w') as f:
            for image_path in train_image_paths:
                f.write(os.path.abspath(image_path) + '\n')
        with open(val_path, 'w') as f:
            for image_path in val_image_paths:
                f.write(os.path.abspath(image_path) + '\n')
        with open(test_path, 'w') as f:
            for image_path in test_image_paths:
                f.write(os.path.abspath(image_path) + '\n')

        # write training YAML file
        with open('./data/citycam.yaml', 'w') as f:
            f.write("train: " + os.path.abspath(train_path) + "\n")
            f.write("val: " + os.path.abspath(val_path) + "\n")
            f.write("test: " + os.path.abspath(test_path) + "\n")
            # number of classes
            f.write('nc: 80\n')
            # class names
            f.write('names: ' + str(CLASS_NAME))

    elif args.ques == 'Q3':
        test_path = os.path.join(args.data_folder, 'Q3_test.txt')
        with open(test_path, 'w') as f:
            for image_path in test_image_paths:
                f.write(os.path.abspath(image_path) + '\n')
        with open('./data/Q3_test.yaml', 'w') as f:
            f.write("test: " + os.path.abspath(test_path) + "\n")
            # number of classes
            f.write('nc: 80\n')
            # class names
            f.write('names: ' + str(CLASS_NAME))

    else:
        train_path = os.path.join(args.data_folder, 'train.txt')
        val_path = os.path.join(args.data_folder, 'val.txt')
        test_path = os.path.join(args.data_folder, 'test.txt')
        with open(train_path, 'w') as f:
            for image_path in train_image_paths:
                f.write(os.path.abspath(image_path) + '\n')
        with open(val_path, 'w') as f:
            for image_path in val_image_paths:
                f.write(os.path.abspath(image_path) + '\n')
        with open(test_path, 'w') as f:
            for image_path in test_image_paths:
                f.write(os.path.abspath(image_path) + '\n')

        # write training YAML file
        with open(f'./data/{args.ques}.yaml', 'w') as f:
            f.write("train: " + os.path.abspath(train_path) + "\n")
            f.write("val: " + os.path.abspath(val_path) + "\n")
            f.write("test: " + os.path.abspath(test_path) + "\n")
            # number of classes
            f.write('nc: 80\n')
            # class names
            f.write('names: ' + str(CLASS_NAME))

    # delete cache
    if os.path.exists(os.path.join(args.data_folder, 'train.cache')):
        os.remove(os.path.join(args.data_folder, 'train.cache'))
    if os.path.exists(os.path.join(args.data_folder, 'val.cache')):
        os.remove(os.path.join(args.data_folder, 'val.cache'))
    """
    if os.path.exists(os.path.join(args.data_folder, 'test.cache')):
        os.remove(os.path.join(args.data_folder, 'test.cache'))
        """
